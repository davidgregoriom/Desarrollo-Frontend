"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/episode/[id]";
exports.ids = ["pages/episode/[id]"];
exports.modules = {

/***/ "./src/components/Episode.tsx":
/*!************************************!*\
  !*** ./src/components/Episode.tsx ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n\nconst Episodes = ({ data  })=>{\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"h1\", {\n                children: \"Episode\"\n            }, void 0, false, {\n                fileName: \"/home/david/Uni/IW/Practicas/Practica4/front/src/components/Episode.tsx\",\n                lineNumber: 10,\n                columnNumber: 9\n            }, undefined),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"ul\", {\n                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"li\", {\n                    children: [\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"h2\", {\n                            children: data.name\n                        }, void 0, false, {\n                            fileName: \"/home/david/Uni/IW/Practicas/Practica4/front/src/components/Episode.tsx\",\n                            lineNumber: 13,\n                            columnNumber: 15\n                        }, undefined),\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"p\", {\n                            children: [\n                                \"Emision: \",\n                                data.air_date\n                            ]\n                        }, void 0, true, {\n                            fileName: \"/home/david/Uni/IW/Practicas/Practica4/front/src/components/Episode.tsx\",\n                            lineNumber: 14,\n                            columnNumber: 15\n                        }, undefined),\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"p\", {\n                            children: [\n                                \"Personajes: \",\n                                data.characters.map((n)=>{\n                                    return n.name;\n                                })\n                            ]\n                        }, void 0, true, {\n                            fileName: \"/home/david/Uni/IW/Practicas/Practica4/front/src/components/Episode.tsx\",\n                            lineNumber: 15,\n                            columnNumber: 15\n                        }, undefined)\n                    ]\n                }, data.id, true, {\n                    fileName: \"/home/david/Uni/IW/Practicas/Practica4/front/src/components/Episode.tsx\",\n                    lineNumber: 12,\n                    columnNumber: 13\n                }, undefined)\n            }, void 0, false, {\n                fileName: \"/home/david/Uni/IW/Practicas/Practica4/front/src/components/Episode.tsx\",\n                lineNumber: 11,\n                columnNumber: 9\n            }, undefined)\n        ]\n    }, void 0, true);\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Episodes);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tcG9uZW50cy9FcGlzb2RlLnRzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7O0FBTUEsTUFBTUEsV0FBVSxDQUFDLEVBQUVDLEtBQUksRUFBb0IsR0FBSztJQUM5QyxxQkFDRTs7MEJBQ0ksOERBQUNDOzBCQUFHOzs7Ozs7MEJBQ0osOERBQUNDOzBCQUNHLDRFQUFDQzs7c0NBQ0MsOERBQUNDO3NDQUFJSixLQUFLSyxJQUFJOzs7Ozs7c0NBQ2QsOERBQUNDOztnQ0FBRTtnQ0FBVU4sS0FBS08sUUFBUTs7Ozs7OztzQ0FDMUIsOERBQUNEOztnQ0FBRTtnQ0FBYU4sS0FBS1EsVUFBVSxDQUFDQyxHQUFHLENBQUNDLENBQUFBLElBQUc7b0NBQUMsT0FBT0EsRUFBRUwsSUFBSTtnQ0FBQzs7Ozs7Ozs7bUJBSC9DTCxLQUFLVyxFQUFFOzs7Ozs7Ozs7Ozs7QUFRNUI7QUFDQSxpRUFBZVosUUFBUUEsRUFBQyIsInNvdXJjZXMiOlsid2VicGFjazovL2Zyb250Ly4vc3JjL2NvbXBvbmVudHMvRXBpc29kZS50c3g/Mzc1ZSJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgZ2V0Q2xpZW50IGZyb20gXCJAL2xpYnMvY2xpZW50XCI7XG5pbXBvcnQgeyBFcGlzb2RlLCBFcGlzb2RlQVBJLCB9IGZyb20gXCJAL3R5cGVzXCI7XG5pbXBvcnQgeyB1c2VRdWVyeSB9IGZyb20gXCJAYXBvbGxvL2NsaWVudFwiO1xuaW1wb3J0IHsgRkMsIHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcblxuXG5jb25zdCBFcGlzb2Rlcz0gKHsgZGF0YSB9OiB7IGRhdGE6IEVwaXNvZGV9KSAgPT57XG4gIHJldHVybiAoXG4gICAgPD5cbiAgICAgICAgPGgxPkVwaXNvZGU8L2gxPlxuICAgICAgICA8dWw+XG4gICAgICAgICAgICA8bGkga2V5PXtkYXRhLmlkfT5cbiAgICAgICAgICAgICAgPGgyPntkYXRhLm5hbWV9PC9oMj5cbiAgICAgICAgICAgICAgPHA+RW1pc2lvbjoge2RhdGEuYWlyX2RhdGV9PC9wPlxuICAgICAgICAgICAgICA8cD5QZXJzb25hamVzOiB7ZGF0YS5jaGFyYWN0ZXJzLm1hcChuPT57cmV0dXJuKG4ubmFtZSl9KX08L3A+XG4gICAgICAgICAgICA8L2xpPlxuICAgICAgICA8L3VsPlxuICAgIDwvPlxuICApXG59XG5leHBvcnQgZGVmYXVsdCBFcGlzb2RlcztcbiJdLCJuYW1lcyI6WyJFcGlzb2RlcyIsImRhdGEiLCJoMSIsInVsIiwibGkiLCJoMiIsIm5hbWUiLCJwIiwiYWlyX2RhdGUiLCJjaGFyYWN0ZXJzIiwibWFwIiwibiIsImlkIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./src/components/Episode.tsx\n");

/***/ }),

/***/ "./src/pages/episode/[id].tsx":
/*!************************************!*\
  !*** ./src/pages/episode/[id].tsx ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__),\n/* harmony export */   \"getServerSideProps\": () => (/* binding */ getServerSideProps)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _components_Episode__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/components/Episode */ \"./src/components/Episode.tsx\");\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @apollo/client */ \"@apollo/client\");\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/router */ \"next/router\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);\n\n\n\n\n\nconst getServerSideProps = async (episode)=>{\n    const query = _apollo_client__WEBPACK_IMPORTED_MODULE_2__.gql`\n    query episode ($id: ID!) {\n      episode (id: $id) {\n        id,\n        name,\n        air_date,\n        characters {\n          id\n          name,\n        }\n      }\n    }\n  `;\n    const route = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();\n    const { id  } = route.query;\n    console.log(id);\n    const { data  } = (0,_apollo_client__WEBPACK_IMPORTED_MODULE_2__.useQuery)(query, {\n        variables: {\n            id\n        }\n    });\n    if (!episode) {\n        return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n            children: \"Cargando...\"\n        }, void 0, false, {\n            fileName: \"/home/david/Uni/IW/Practicas/Practica4/front/src/pages/episode/[id].tsx\",\n            lineNumber: 37,\n            columnNumber: 11\n        }, undefined);\n    }\n    return {\n        props: {\n            data: data.data\n        }\n    };\n};\nconst EpisodePage = ({ data  })=>{\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_Episode__WEBPACK_IMPORTED_MODULE_1__[\"default\"], {\n        data: data\n    }, void 0, false, {\n        fileName: \"/home/david/Uni/IW/Practicas/Practica4/front/src/pages/episode/[id].tsx\",\n        lineNumber: 47,\n        columnNumber: 10\n    }, undefined);\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (EpisodePage);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvcGFnZXMvZXBpc29kZS9baWRdLnRzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7QUFBNEM7QUFLRztBQUVQO0FBQ047QUFHM0IsTUFBTUsscUJBQXlDLE9BQU9DLFVBQVk7SUFFdkUsTUFBTUMsUUFBT04sK0NBQUcsQ0FBQzs7Ozs7Ozs7Ozs7O0VBWWpCLENBQUM7SUFHRCxNQUFNTyxRQUFPTCxzREFBU0E7SUFDdEIsTUFBTSxFQUFDTSxHQUFFLEVBQUMsR0FBRUQsTUFBTUQsS0FBSztJQUN2QkcsUUFBUUMsR0FBRyxDQUFDRjtJQUVWLE1BQU0sRUFBRUcsS0FBSSxFQUFFLEdBQUdWLHdEQUFRQSxDQUFDSyxPQUN2QjtRQUFDTSxXQUFVO1lBQUNKO1FBQUU7SUFBQztJQUVwQixJQUFHLENBQUNILFNBQVE7UUFDVixxQkFBTSw4REFBQ1E7c0JBQUk7Ozs7OztJQUNiLENBQUM7SUFDRCxPQUFNO1FBQ0pDLE9BQU07WUFDSkgsTUFBS0EsS0FBS0EsSUFBSTtRQUNoQjtJQUNGO0FBRUYsRUFBQztBQUNELE1BQU1JLGNBQWMsQ0FBQyxFQUFDSixLQUFJLEVBQWdCLEdBQUc7SUFDM0MscUJBQU8sOERBQUNaLDJEQUFRQTtRQUFDWSxNQUFNQTs7Ozs7O0FBRXpCO0FBQ0EsaUVBQWVJLFdBQVdBLEVBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9mcm9udC8uL3NyYy9wYWdlcy9lcGlzb2RlL1tpZF0udHN4P2VmY2IiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IEVwaXNvZGVzIGZyb20gXCJAL2NvbXBvbmVudHMvRXBpc29kZVwiO1xuaW1wb3J0IGNsaWVudCBmcm9tIFwiQC9saWJzL2NsaWVudFwiO1xuaW1wb3J0IGdldFNTUkNsaWVudCBmcm9tIFwiQC9saWJzL2NsaWVudFwiO1xuaW1wb3J0IHsgcXVlcnkgfSBmcm9tIFwiQC9zY2hlbWFzXCI7XG5pbXBvcnQgeyBFcGlzb2RlQVBJICxFcGlzb2RlfSBmcm9tIFwiQC90eXBlc1wiO1xuaW1wb3J0IHsgZ3FsLCB1c2VRdWVyeSB9IGZyb20gXCJAYXBvbGxvL2NsaWVudFwiO1xuaW1wb3J0IHsgR2V0U2VydmVyU2lkZVByb3BzLCBOZXh0UGFnZSB9IGZyb20gXCJuZXh0XCI7XG5pbXBvcnQgeyB1c2VSb3V0ZXIgfSBmcm9tIFwibmV4dC9yb3V0ZXJcIjtcbmltcG9ydCBSZWFjdCwgeyBGQyB9IGZyb20gXCJyZWFjdFwiO1xuXG5cbmV4cG9ydCBjb25zdCBnZXRTZXJ2ZXJTaWRlUHJvcHM6IEdldFNlcnZlclNpZGVQcm9wcyA9IGFzeW5jIChlcGlzb2RlKSA9PiB7XG5cbiAgY29uc3QgcXVlcnk9IGdxbGBcbiAgICBxdWVyeSBlcGlzb2RlICgkaWQ6IElEISkge1xuICAgICAgZXBpc29kZSAoaWQ6ICRpZCkge1xuICAgICAgICBpZCxcbiAgICAgICAgbmFtZSxcbiAgICAgICAgYWlyX2RhdGUsXG4gICAgICAgIGNoYXJhY3RlcnMge1xuICAgICAgICAgIGlkXG4gICAgICAgICAgbmFtZSxcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgYFxuXG5cbiAgY29uc3Qgcm91dGUgPXVzZVJvdXRlcigpO1xuICBjb25zdCB7aWR9ID1yb3V0ZS5xdWVyeTtcbiAgY29uc29sZS5sb2coaWQpO1xuXG4gICAgY29uc3QgeyBkYXRhIH0gPSB1c2VRdWVyeShxdWVyeVxuICAgICAgLHt2YXJpYWJsZXM6e2lkfX0pO1xuXG4gIGlmKCFlcGlzb2RlKXtcbiAgICByZXR1cm48ZGl2PkNhcmdhbmRvLi4uPC9kaXY+XG4gIH1cbiAgcmV0dXJue1xuICAgIHByb3BzOntcbiAgICAgIGRhdGE6ZGF0YS5kYXRhLFxuICAgIH1cbiAgfVxuXG59XG5jb25zdCBFcGlzb2RlUGFnZSA9ICh7ZGF0YX06e2RhdGE6RXBpc29kZX0pPT57XG4gIHJldHVybiA8RXBpc29kZXMgZGF0YT17ZGF0YX0vPjtcblxufVxuZXhwb3J0IGRlZmF1bHQgRXBpc29kZVBhZ2U7XG4iXSwibmFtZXMiOlsiRXBpc29kZXMiLCJncWwiLCJ1c2VRdWVyeSIsInVzZVJvdXRlciIsIlJlYWN0IiwiZ2V0U2VydmVyU2lkZVByb3BzIiwiZXBpc29kZSIsInF1ZXJ5Iiwicm91dGUiLCJpZCIsImNvbnNvbGUiLCJsb2ciLCJkYXRhIiwidmFyaWFibGVzIiwiZGl2IiwicHJvcHMiLCJFcGlzb2RlUGFnZSJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./src/pages/episode/[id].tsx\n");

/***/ }),

/***/ "@apollo/client":
/*!*********************************!*\
  !*** external "@apollo/client" ***!
  \*********************************/
/***/ ((module) => {

module.exports = require("@apollo/client");

/***/ }),

/***/ "next/router":
/*!******************************!*\
  !*** external "next/router" ***!
  \******************************/
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./src/pages/episode/[id].tsx"));
module.exports = __webpack_exports__;

})();