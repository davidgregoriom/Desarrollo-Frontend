"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/characters";
exports.ids = ["pages/characters"];
exports.modules = {

/***/ "./src/components/CharactersPage.tsx":
/*!*******************************************!*\
  !*** ./src/components/CharactersPage.tsx ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @apollo/client */ \"@apollo/client\");\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _styles_styles__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/styles/styles */ \"./src/styles/styles.tsx\");\n\n\n\n\nconst CharactersPage = ({ page  })=>{\n    const query = _apollo_client__WEBPACK_IMPORTED_MODULE_1__.gql`\n    query characters($page : Int!){\n      characters(page:$page ){\n      results{\n        name,\n        image,\n        id\n      }\n    }\n  }\n\n  `;\n    const [charPage, setPage] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(page);\n    const { loading , error , data , refetch  } = (0,_apollo_client__WEBPACK_IMPORTED_MODULE_1__.useQuery)(query, {\n        variables: {\n            page: charPage,\n            prev: charPage - 1,\n            next: charPage + 1\n        }\n    });\n    if (loading) return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        children: \"Cargando...\"\n    }, void 0, false, {\n        fileName: \"/home/david/Uni/IW/Practicas/Practica4/front/src/components/CharactersPage.tsx\",\n        lineNumber: 36,\n        columnNumber: 22\n    }, undefined);\n    if (error) return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        children: \"Error\"\n    }, void 0, false, {\n        fileName: \"/home/david/Uni/IW/Practicas/Practica4/front/src/components/CharactersPage.tsx\",\n        lineNumber: 37,\n        columnNumber: 20\n    }, undefined);\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_styles_styles__WEBPACK_IMPORTED_MODULE_3__.Contenedor, {\n                children: data?.characters.results.map((character)=>{\n                    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_styles_styles__WEBPACK_IMPORTED_MODULE_3__.StyledC, {\n                        children: [\n                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_styles_styles__WEBPACK_IMPORTED_MODULE_3__.StyledI, {\n                                src: character.image,\n                                width: \"200px\",\n                                height: \"200px\"\n                            }, void 0, false, {\n                                fileName: \"/home/david/Uni/IW/Practicas/Practica4/front/src/components/CharactersPage.tsx\",\n                                lineNumber: 47,\n                                columnNumber: 17\n                            }, undefined),\n                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"h1\", {\n                                children: character.name\n                            }, void 0, false, {\n                                fileName: \"/home/david/Uni/IW/Practicas/Practica4/front/src/components/CharactersPage.tsx\",\n                                lineNumber: 49,\n                                columnNumber: 17\n                            }, undefined)\n                        ]\n                    }, void 0, true, {\n                        fileName: \"/home/david/Uni/IW/Practicas/Practica4/front/src/components/CharactersPage.tsx\",\n                        lineNumber: 45,\n                        columnNumber: 15\n                    }, undefined);\n                })\n            }, void 0, false, {\n                fileName: \"/home/david/Uni/IW/Practicas/Practica4/front/src/components/CharactersPage.tsx\",\n                lineNumber: 40,\n                columnNumber: 7\n            }, undefined),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n                onClick: ()=>{\n                    setPage(charPage - 1);\n                },\n                children: \"Anterior\"\n            }, void 0, false, {\n                fileName: \"/home/david/Uni/IW/Practicas/Practica4/front/src/components/CharactersPage.tsx\",\n                lineNumber: 57,\n                columnNumber: 11\n            }, undefined),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n                onClick: ()=>{\n                    setPage(charPage + 1);\n                },\n                children: \"Siguiente\"\n            }, void 0, false, {\n                fileName: \"/home/david/Uni/IW/Practicas/Practica4/front/src/components/CharactersPage.tsx\",\n                lineNumber: 58,\n                columnNumber: 11\n            }, undefined)\n        ]\n    }, void 0, true, {\n        fileName: \"/home/david/Uni/IW/Practicas/Practica4/front/src/components/CharactersPage.tsx\",\n        lineNumber: 39,\n        columnNumber: 5\n    }, undefined);\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CharactersPage);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tcG9uZW50cy9DaGFyYWN0ZXJzUGFnZS50c3guanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7O0FBQTZDO0FBRVE7QUFHTTtBQUczRCxNQUFNTyxpQkFBaUMsQ0FBQyxFQUFDQyxLQUFJLEVBQUMsR0FBSTtJQUVoRCxNQUFNQyxRQUFRVCwrQ0FBRyxDQUFDOzs7Ozs7Ozs7OztFQVdsQixDQUFDO0lBRUQsTUFBTSxDQUFDVSxVQUFTQyxRQUFRLEdBQUdSLCtDQUFRQSxDQUFTSztJQUU1QyxNQUFNLEVBQUNJLFFBQU8sRUFBQ0MsTUFBSyxFQUFDQyxLQUFJLEVBQUNDLFFBQU8sRUFBQyxHQUFHZCx3REFBUUEsQ0FDM0NRLE9BQU07UUFDTk8sV0FBVztZQUNUUixNQUFLRTtZQUNMTyxNQUFLUCxXQUFTO1lBQ2RRLE1BQUtSLFdBQVM7UUFDaEI7SUFDRjtJQUdBLElBQUdFLFNBQVMscUJBQU8sOERBQUNPO2tCQUFJOzs7Ozs7SUFDeEIsSUFBR04sT0FBTyxxQkFBTyw4REFBQ007a0JBQUk7Ozs7OztJQUN0QixxQkFDRSw4REFBQ0E7OzBCQUNDLDhEQUFDZixzREFBVUE7MEJBRVJVLE1BQU1NLFdBQVdDLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDLENBQUNDLFlBQXlCO29CQUN0RCxxQkFFSSw4REFBQ2xCLG1EQUFPQTs7MENBRU4sOERBQUNDLG1EQUFPQTtnQ0FBQ2tCLEtBQUtELFVBQVVFLEtBQUs7Z0NBQUVDLE9BQU07Z0NBQVFDLFFBQU87Ozs7OzswQ0FFcEQsOERBQUNDOzBDQUFJTCxVQUFVTSxJQUFJOzs7Ozs7Ozs7Ozs7Z0JBSzNCOzs7Ozs7MEJBR0UsOERBQUNDO2dCQUFPQyxTQUFTLElBQU07b0JBQUVwQixRQUFRRCxXQUFXO2dCQUFJOzBCQUFJOzs7Ozs7MEJBQ3BELDhEQUFDb0I7Z0JBQU9DLFNBQVMsSUFBTTtvQkFBRXBCLFFBQVFELFdBQVc7Z0JBQUk7MEJBQUk7Ozs7Ozs7Ozs7OztBQUc5RDtBQUVBLGlFQUFlSCxjQUFjQSxFQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vZnJvbnQvLi9zcmMvY29tcG9uZW50cy9DaGFyYWN0ZXJzUGFnZS50c3g/YTBiNyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge2dxbCwgdXNlUXVlcnl9IGZyb20gXCJAYXBvbGxvL2NsaWVudFwiO1xuaW1wb3J0IGdldENsaWVudCBmcm9tIFwiLi4vbGlicy9jbGllbnRcIjtcbmltcG9ydCBSZWFjdCwge0ZDLCB1c2VFZmZlY3QsIHVzZVN0YXRlfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IHF1ZXJ5IH0gZnJvbSBcIkAvc2NoZW1hc1wiXG5pbXBvcnQgeyBDaGFyYWN0ZXJzLCBDaGFyYWN0ZXJBUEkgfSBmcm9tIFwiQC90eXBlc1wiO1xuaW1wb3J0ICB7Q29udGVuZWRvcixTdHlsZWRDLFN0eWxlZEl9IGZyb20gXCJAL3N0eWxlcy9zdHlsZXNcIlxuXG5cbmNvbnN0IENoYXJhY3RlcnNQYWdlOkZDPHtwYWdlOm51bWJlcn0+PSh7cGFnZX0pPT4ge1xuXG4gIGNvbnN0IHF1ZXJ5ID0gZ3FsYFxuICAgIHF1ZXJ5IGNoYXJhY3RlcnMoJHBhZ2UgOiBJbnQhKXtcbiAgICAgIGNoYXJhY3RlcnMocGFnZTokcGFnZSApe1xuICAgICAgcmVzdWx0c3tcbiAgICAgICAgbmFtZSxcbiAgICAgICAgaW1hZ2UsXG4gICAgICAgIGlkXG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgYFxuXG4gIGNvbnN0IFtjaGFyUGFnZSxzZXRQYWdlXSA9IHVzZVN0YXRlPG51bWJlcj4ocGFnZSk7XG5cbiAgY29uc3Qge2xvYWRpbmcsZXJyb3IsZGF0YSxyZWZldGNofSA9IHVzZVF1ZXJ5PENoYXJhY3RlcnM+KFxuICAgIHF1ZXJ5LHtcbiAgICB2YXJpYWJsZXM6IHtcbiAgICAgIHBhZ2U6Y2hhclBhZ2UsXG4gICAgICBwcmV2OmNoYXJQYWdlLTEsXG4gICAgICBuZXh0OmNoYXJQYWdlKzFcbiAgICB9XG4gIH1cbiAgKTtcblxuICBpZihsb2FkaW5nKSByZXR1cm4gPGRpdj5DYXJnYW5kby4uLjwvZGl2PlxuICBpZihlcnJvcikgcmV0dXJuIDxkaXY+RXJyb3I8L2Rpdj5cbiAgcmV0dXJuKFxuICAgIDxkaXY+XG4gICAgICA8Q29udGVuZWRvcj5cblxuICAgICAgICB7ZGF0YT8uY2hhcmFjdGVycy5yZXN1bHRzLm1hcCgoY2hhcmFjdGVyOkNoYXJhY3RlckFQSSk9PntcbiAgICAgICAgICByZXR1cm4gKFxuXG4gICAgICAgICAgICAgIDxTdHlsZWRDPlxuXG4gICAgICAgICAgICAgICAgPFN0eWxlZEkgc3JjPXtjaGFyYWN0ZXIuaW1hZ2V9IHdpZHRoPVwiMjAwcHhcIiBoZWlnaHQ9XCIyMDBweFwiPjwvU3R5bGVkST5cblxuICAgICAgICAgICAgICAgIDxoMT57Y2hhcmFjdGVyLm5hbWUgfTwvaDE+XG4gICAgICAgICAgICAgIDwvU3R5bGVkQz5cblxuXG4gICAgICAgICAgKVxuICAgICAgICB9KX1cblxuICAgICAgPC9Db250ZW5lZG9yPlxuICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4geyBzZXRQYWdlKGNoYXJQYWdlIC0gMSk7IH0gfT5BbnRlcmlvcjwvYnV0dG9uPlxuICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4geyBzZXRQYWdlKGNoYXJQYWdlICsgMSk7IH0gfT5TaWd1aWVudGU8L2J1dHRvbj5cbiAgICA8L2Rpdj5cbiAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBDaGFyYWN0ZXJzUGFnZTtcbiJdLCJuYW1lcyI6WyJncWwiLCJ1c2VRdWVyeSIsIlJlYWN0IiwidXNlU3RhdGUiLCJDb250ZW5lZG9yIiwiU3R5bGVkQyIsIlN0eWxlZEkiLCJDaGFyYWN0ZXJzUGFnZSIsInBhZ2UiLCJxdWVyeSIsImNoYXJQYWdlIiwic2V0UGFnZSIsImxvYWRpbmciLCJlcnJvciIsImRhdGEiLCJyZWZldGNoIiwidmFyaWFibGVzIiwicHJldiIsIm5leHQiLCJkaXYiLCJjaGFyYWN0ZXJzIiwicmVzdWx0cyIsIm1hcCIsImNoYXJhY3RlciIsInNyYyIsImltYWdlIiwid2lkdGgiLCJoZWlnaHQiLCJoMSIsIm5hbWUiLCJidXR0b24iLCJvbkNsaWNrIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./src/components/CharactersPage.tsx\n");

/***/ }),

/***/ "./src/pages/characters/index.tsx":
/*!****************************************!*\
  !*** ./src/pages/characters/index.tsx ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _components_CharactersPage__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/components/CharactersPage */ \"./src/components/CharactersPage.tsx\");\n\n\nconst Page = ()=>{\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_CharactersPage__WEBPACK_IMPORTED_MODULE_1__[\"default\"], {\n            page: 1\n        }, void 0, false, {\n            fileName: \"/home/david/Uni/IW/Practicas/Practica4/front/src/pages/characters/index.tsx\",\n            lineNumber: 10,\n            columnNumber: 7\n        }, undefined)\n    }, void 0, false);\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Page);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvcGFnZXMvY2hhcmFjdGVycy9pbmRleC50c3guanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFBcUQ7QUFNckQsTUFBTUMsT0FBSyxJQUFLO0lBQ2QscUJBQ0U7a0JBQ0UsNEVBQUNELGtFQUFVQTtZQUFDRSxNQUFNOzs7Ozs7O0FBR3hCO0FBRUEsaUVBQWVELElBQUlBLEVBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9mcm9udC8uL3NyYy9wYWdlcy9jaGFyYWN0ZXJzL2luZGV4LnRzeD8yMTYxIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBDaGFyYWN0ZXJzIGZyb20gXCJAL2NvbXBvbmVudHMvQ2hhcmFjdGVyc1BhZ2VcIjtcbmltcG9ydCB7IE5leHRQYWdlIH0gZnJvbSBcIm5leHRcIjtcblxuXG5cblxuY29uc3QgUGFnZT0oKT0+IHtcbiAgcmV0dXJuIChcbiAgICA8PlxuICAgICAgPENoYXJhY3RlcnMgcGFnZT17MX0vPlxuICAgIDwvPlxuICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IFBhZ2U7XG4iXSwibmFtZXMiOlsiQ2hhcmFjdGVycyIsIlBhZ2UiLCJwYWdlIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./src/pages/characters/index.tsx\n");

/***/ }),

/***/ "./src/styles/styles.tsx":
/*!*******************************!*\
  !*** ./src/styles/styles.tsx ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"Contenedor\": () => (/* binding */ Contenedor),\n/* harmony export */   \"StyledC\": () => (/* binding */ StyledC),\n/* harmony export */   \"StyledI\": () => (/* binding */ StyledI)\n/* harmony export */ });\n/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ \"styled-components\");\n/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);\n\nconst Contenedor = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`\n  display: grid;\n  grid-template-columns: repeat(4, 1fr);\n  gap: 1rem;\n`;\nconst StyledC = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`\n  text-decoration: none;\n  color: blue;\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n`;\nconst StyledI = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().img)`\n  width: 100%;\n  height: auto;\n  object-fit: contain;\n  max-width: 150px;\n  max-height: 150px;\n`;\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvc3R5bGVzL3N0eWxlcy50c3guanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFBdUM7QUFDaEMsTUFBTUMsYUFBYUQsOERBQVUsQ0FBQzs7OztBQUlyQyxDQUFDLENBQUM7QUFFSyxNQUFNRyxVQUFVSCw4REFBVSxDQUFDOzs7Ozs7QUFNbEMsQ0FBQyxDQUFDO0FBRUssTUFBTUksVUFBVUosOERBQVUsQ0FBQzs7Ozs7O0FBTWxDLENBQUMsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL2Zyb250Ly4vc3JjL3N0eWxlcy9zdHlsZXMudHN4P2JkMTMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHN0eWxlZCBmcm9tIFwic3R5bGVkLWNvbXBvbmVudHNcIjtcbmV4cG9ydCBjb25zdCBDb250ZW5lZG9yID0gc3R5bGVkLmRpdmBcbiAgZGlzcGxheTogZ3JpZDtcbiAgZ3JpZC10ZW1wbGF0ZS1jb2x1bW5zOiByZXBlYXQoNCwgMWZyKTtcbiAgZ2FwOiAxcmVtO1xuYDtcblxuZXhwb3J0IGNvbnN0IFN0eWxlZEMgPSBzdHlsZWQuZGl2YFxuICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XG4gIGNvbG9yOiBibHVlO1xuICBkaXNwbGF5OiBmbGV4O1xuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuYDtcblxuZXhwb3J0IGNvbnN0IFN0eWxlZEkgPSBzdHlsZWQuaW1nYFxuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiBhdXRvO1xuICBvYmplY3QtZml0OiBjb250YWluO1xuICBtYXgtd2lkdGg6IDE1MHB4O1xuICBtYXgtaGVpZ2h0OiAxNTBweDtcbmA7XG4iXSwibmFtZXMiOlsic3R5bGVkIiwiQ29udGVuZWRvciIsImRpdiIsIlN0eWxlZEMiLCJTdHlsZWRJIiwiaW1nIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./src/styles/styles.tsx\n");

/***/ }),

/***/ "@apollo/client":
/*!*********************************!*\
  !*** external "@apollo/client" ***!
  \*********************************/
/***/ ((module) => {

module.exports = require("@apollo/client");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "styled-components":
/*!************************************!*\
  !*** external "styled-components" ***!
  \************************************/
/***/ ((module) => {

module.exports = require("styled-components");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./src/pages/characters/index.tsx"));
module.exports = __webpack_exports__;

})();