/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/_app";
exports.ids = ["pages/_app"];
exports.modules = {

/***/ "./src/libs/client.ts":
/*!****************************!*\
  !*** ./src/libs/client.ts ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @apollo/client */ \"@apollo/client\");\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_0__);\n\n// const client = new ApolloClient({\n//     uri: \"https://loquesea.com/graphql\",\n//     cache: new InMemoryCache(),\n// })\nlet client = undefined;\nconst CSRClient = new _apollo_client__WEBPACK_IMPORTED_MODULE_0__.ApolloClient({\n    uri: \"https://rickandmortyapi.com/graphql\",\n    cache: new _apollo_client__WEBPACK_IMPORTED_MODULE_0__.InMemoryCache()\n});\nconst getSSRClient = ()=>{\n    if (true) {\n        return new _apollo_client__WEBPACK_IMPORTED_MODULE_0__.ApolloClient({\n            uri: \"https://rickandmortyapi.com/graphql\",\n            cache: new _apollo_client__WEBPACK_IMPORTED_MODULE_0__.InMemoryCache()\n        });\n    } else {}\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (getSSRClient);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvbGlicy9jbGllbnQudHMuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQWlGO0FBRWpGLG9DQUFvQztBQUNwQywyQ0FBMkM7QUFDM0Msa0NBQWtDO0FBQ2xDLEtBQUs7QUFFTCxJQUFJRSxTQUF5REM7QUFDN0QsTUFBTUMsWUFBWSxJQUFJSCx3REFBWUEsQ0FBQztJQUMvQkksS0FBSztJQUNMQyxPQUFPLElBQUlOLHlEQUFhQTtBQUM1QjtBQUVDLE1BQU1PLGVBQWUsSUFBTTtJQUN4QixJQUFHLElBQTZCLEVBQUM7UUFDN0IsT0FBTyxJQUFJTix3REFBWUEsQ0FBQztZQUNwQkksS0FBSztZQUNMQyxPQUFPLElBQUlOLHlEQUFhQTtRQUM1QjtJQUNKLE9BQUssRUFFSjtBQUNMO0FBRUEsaUVBQWVPLFlBQVlBLEVBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9mcm9udC8uL3NyYy9saWJzL2NsaWVudC50cz8xYmVhIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydHtJbk1lbW9yeUNhY2hlLCBBcG9sbG9DbGllbnQsIE5vcm1hbGl6ZWRDYWNoZU9iamVjdH0gZnJvbSBcIkBhcG9sbG8vY2xpZW50XCI7XG5cbi8vIGNvbnN0IGNsaWVudCA9IG5ldyBBcG9sbG9DbGllbnQoe1xuLy8gICAgIHVyaTogXCJodHRwczovL2xvcXVlc2VhLmNvbS9ncmFwaHFsXCIsXG4vLyAgICAgY2FjaGU6IG5ldyBJbk1lbW9yeUNhY2hlKCksXG4vLyB9KVxuXG5sZXQgY2xpZW50IDogQXBvbGxvQ2xpZW50PE5vcm1hbGl6ZWRDYWNoZU9iamVjdD58dW5kZWZpbmVkID0gdW5kZWZpbmVkO1xuY29uc3QgQ1NSQ2xpZW50ID0gbmV3IEFwb2xsb0NsaWVudCh7XG4gICAgdXJpOiBcImh0dHBzOi8vcmlja2FuZG1vcnR5YXBpLmNvbS9ncmFwaHFsXCIsXG4gICAgY2FjaGU6IG5ldyBJbk1lbW9yeUNhY2hlKCksXG59KVxuXG4gY29uc3QgZ2V0U1NSQ2xpZW50ID0gKCkgPT4ge1xuICAgIGlmKHR5cGVvZiB3aW5kb3cgPT09IFwidW5kZWZpbmVkXCIpe1xuICAgICAgICByZXR1cm4gbmV3IEFwb2xsb0NsaWVudCh7XG4gICAgICAgICAgICB1cmk6IFwiaHR0cHM6Ly9yaWNrYW5kbW9ydHlhcGkuY29tL2dyYXBocWxcIixcbiAgICAgICAgICAgIGNhY2hlOiBuZXcgSW5NZW1vcnlDYWNoZSgpLFxuICAgICAgICB9KVxuICAgIH1lbHNle1xuICAgICAgICByZXR1cm4gQ1NSQ2xpZW50O1xuICAgIH1cbn1cblxuZXhwb3J0IGRlZmF1bHQgZ2V0U1NSQ2xpZW50O1xuIl0sIm5hbWVzIjpbIkluTWVtb3J5Q2FjaGUiLCJBcG9sbG9DbGllbnQiLCJjbGllbnQiLCJ1bmRlZmluZWQiLCJDU1JDbGllbnQiLCJ1cmkiLCJjYWNoZSIsImdldFNTUkNsaWVudCJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./src/libs/client.ts\n");

/***/ }),

/***/ "./src/pages/_app.tsx":
/*!****************************!*\
  !*** ./src/pages/_app.tsx ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ App)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/styles/globals.css */ \"./src/styles/globals.css\");\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_styles_globals_css__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @apollo/client */ \"@apollo/client\");\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _libs_client__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/libs/client */ \"./src/libs/client.ts\");\n\n\n\n\nfunction App({ Component , pageProps  }) {\n    const client = (0,_libs_client__WEBPACK_IMPORTED_MODULE_3__[\"default\"])();\n    return(// @ts-ignore\n    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_apollo_client__WEBPACK_IMPORTED_MODULE_2__.ApolloProvider, {\n        client: client,\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Component, {\n            ...pageProps\n        }, void 0, false, {\n            fileName: \"/home/david/Uni/IW/Practicas/Practica4/front/src/pages/_app.tsx\",\n            lineNumber: 11,\n            columnNumber: 7\n        }, this)\n    }, void 0, false, {\n        fileName: \"/home/david/Uni/IW/Practicas/Practica4/front/src/pages/_app.tsx\",\n        lineNumber: 10,\n        columnNumber: 5\n    }, this));\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvcGFnZXMvX2FwcC50c3guanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7O0FBQTZCO0FBRW1CO0FBQ1A7QUFFMUIsU0FBU0UsSUFBSSxFQUFFQyxVQUFTLEVBQUVDLFVBQVMsRUFBWSxFQUFFO0lBQzlELE1BQU1DLFNBQVNKLHdEQUFZQTtJQUMzQixPQUNFLGFBQWE7a0JBQ2IsOERBQUNELDBEQUFjQTtRQUFDSyxRQUFVQTtrQkFDeEIsNEVBQUNGO1lBQVcsR0FBR0MsU0FBUzs7Ozs7Ozs7Ozs7QUFFOUIsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL2Zyb250Ly4vc3JjL3BhZ2VzL19hcHAudHN4P2Y5ZDYiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0ICdAL3N0eWxlcy9nbG9iYWxzLmNzcydcbmltcG9ydCB0eXBlIHsgQXBwUHJvcHMgfSBmcm9tICduZXh0L2FwcCdcbmltcG9ydCB7IEFwb2xsb1Byb3ZpZGVyIH0gZnJvbSBcIkBhcG9sbG8vY2xpZW50XCI7XG5pbXBvcnQgZ2V0U1NSQ2xpZW50IGZyb20gXCJAL2xpYnMvY2xpZW50XCI7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEFwcCh7IENvbXBvbmVudCwgcGFnZVByb3BzIH06IEFwcFByb3BzKSB7XG4gIGNvbnN0IGNsaWVudCA9IGdldFNTUkNsaWVudCgpO1xuICByZXR1cm4oXG4gICAgLy8gQHRzLWlnbm9yZVxuICAgIDxBcG9sbG9Qcm92aWRlciBjbGllbnQgPSB7Y2xpZW50fT5cbiAgICAgIDxDb21wb25lbnQgey4uLnBhZ2VQcm9wc30gLz5cbiAgICA8L0Fwb2xsb1Byb3ZpZGVyPilcbn1cbiJdLCJuYW1lcyI6WyJBcG9sbG9Qcm92aWRlciIsImdldFNTUkNsaWVudCIsIkFwcCIsIkNvbXBvbmVudCIsInBhZ2VQcm9wcyIsImNsaWVudCJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./src/pages/_app.tsx\n");

/***/ }),

/***/ "./src/styles/globals.css":
/*!********************************!*\
  !*** ./src/styles/globals.css ***!
  \********************************/
/***/ (() => {



/***/ }),

/***/ "@apollo/client":
/*!*********************************!*\
  !*** external "@apollo/client" ***!
  \*********************************/
/***/ ((module) => {

"use strict";
module.exports = require("@apollo/client");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./src/pages/_app.tsx"));
module.exports = __webpack_exports__;

})();