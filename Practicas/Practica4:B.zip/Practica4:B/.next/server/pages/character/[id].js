"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/character/[id]";
exports.ids = ["pages/character/[id]"];
exports.modules = {

/***/ "./src/libs/client.ts":
/*!****************************!*\
  !*** ./src/libs/client.ts ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @apollo/client */ \"@apollo/client\");\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_0__);\n\n// const client = new ApolloClient({\n//     uri: \"https://loquesea.com/graphql\",\n//     cache: new InMemoryCache(),\n// })\nlet client = undefined;\nconst CSRClient = new _apollo_client__WEBPACK_IMPORTED_MODULE_0__.ApolloClient({\n    uri: \"https://rickandmortyapi.com/graphql\",\n    cache: new _apollo_client__WEBPACK_IMPORTED_MODULE_0__.InMemoryCache()\n});\nconst getSSRClient = ()=>{\n    if (true) {\n        return new _apollo_client__WEBPACK_IMPORTED_MODULE_0__.ApolloClient({\n            uri: \"https://rickandmortyapi.com/graphql\",\n            cache: new _apollo_client__WEBPACK_IMPORTED_MODULE_0__.InMemoryCache()\n        });\n    } else {}\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (getSSRClient);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvbGlicy9jbGllbnQudHMuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQWlGO0FBRWpGLG9DQUFvQztBQUNwQywyQ0FBMkM7QUFDM0Msa0NBQWtDO0FBQ2xDLEtBQUs7QUFFTCxJQUFJRSxTQUF5REM7QUFDN0QsTUFBTUMsWUFBWSxJQUFJSCx3REFBWUEsQ0FBQztJQUMvQkksS0FBSztJQUNMQyxPQUFPLElBQUlOLHlEQUFhQTtBQUM1QjtBQUVDLE1BQU1PLGVBQWUsSUFBTTtJQUN4QixJQUFHLElBQTZCLEVBQUM7UUFDN0IsT0FBTyxJQUFJTix3REFBWUEsQ0FBQztZQUNwQkksS0FBSztZQUNMQyxPQUFPLElBQUlOLHlEQUFhQTtRQUM1QjtJQUNKLE9BQUssRUFFSjtBQUNMO0FBRUEsaUVBQWVPLFlBQVlBLEVBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9mcm9udC8uL3NyYy9saWJzL2NsaWVudC50cz8xYmVhIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydHtJbk1lbW9yeUNhY2hlLCBBcG9sbG9DbGllbnQsIE5vcm1hbGl6ZWRDYWNoZU9iamVjdH0gZnJvbSBcIkBhcG9sbG8vY2xpZW50XCI7XG5cbi8vIGNvbnN0IGNsaWVudCA9IG5ldyBBcG9sbG9DbGllbnQoe1xuLy8gICAgIHVyaTogXCJodHRwczovL2xvcXVlc2VhLmNvbS9ncmFwaHFsXCIsXG4vLyAgICAgY2FjaGU6IG5ldyBJbk1lbW9yeUNhY2hlKCksXG4vLyB9KVxuXG5sZXQgY2xpZW50IDogQXBvbGxvQ2xpZW50PE5vcm1hbGl6ZWRDYWNoZU9iamVjdD58dW5kZWZpbmVkID0gdW5kZWZpbmVkO1xuY29uc3QgQ1NSQ2xpZW50ID0gbmV3IEFwb2xsb0NsaWVudCh7XG4gICAgdXJpOiBcImh0dHBzOi8vcmlja2FuZG1vcnR5YXBpLmNvbS9ncmFwaHFsXCIsXG4gICAgY2FjaGU6IG5ldyBJbk1lbW9yeUNhY2hlKCksXG59KVxuXG4gY29uc3QgZ2V0U1NSQ2xpZW50ID0gKCkgPT4ge1xuICAgIGlmKHR5cGVvZiB3aW5kb3cgPT09IFwidW5kZWZpbmVkXCIpe1xuICAgICAgICByZXR1cm4gbmV3IEFwb2xsb0NsaWVudCh7XG4gICAgICAgICAgICB1cmk6IFwiaHR0cHM6Ly9yaWNrYW5kbW9ydHlhcGkuY29tL2dyYXBocWxcIixcbiAgICAgICAgICAgIGNhY2hlOiBuZXcgSW5NZW1vcnlDYWNoZSgpLFxuICAgICAgICB9KVxuICAgIH1lbHNle1xuICAgICAgICByZXR1cm4gQ1NSQ2xpZW50O1xuICAgIH1cbn1cblxuZXhwb3J0IGRlZmF1bHQgZ2V0U1NSQ2xpZW50O1xuIl0sIm5hbWVzIjpbIkluTWVtb3J5Q2FjaGUiLCJBcG9sbG9DbGllbnQiLCJjbGllbnQiLCJ1bmRlZmluZWQiLCJDU1JDbGllbnQiLCJ1cmkiLCJjYWNoZSIsImdldFNTUkNsaWVudCJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./src/libs/client.ts\n");

/***/ }),

/***/ "./src/pages/character/[id].tsx":
/*!**************************************!*\
  !*** ./src/pages/character/[id].tsx ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"getStaticPaths\": () => (/* binding */ getStaticPaths)\n/* harmony export */ });\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @apollo/client */ \"@apollo/client\");\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _libs_client__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/libs/client */ \"./src/libs/client.ts\");\n\n\n\nasync function getStaticPaths() {\n    const client = (0,_libs_client__WEBPACK_IMPORTED_MODULE_2__[\"default\"])();\n    const { data  } = await client.query({\n        query: _apollo_client__WEBPACK_IMPORTED_MODULE_0__.gql`\n        query character ($id: ID!) {\n          character (id: $id) {\n            image,\n            name,\n            gender,\n            location {\n              name,\n            }\n            episode{\n              name,\n            }\n          }\n        }\n      `\n    });\n    return {\n        props: {\n            character: data\n        }\n    };\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvcGFnZXMvY2hhcmFjdGVyL1tpZF0udHN4LmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUE4QztBQUNPO0FBSWY7QUFHL0IsZUFBZUcsaUJBQW9FO0lBQ3hGLE1BQU1DLFNBQVNGLHdEQUFTQTtJQUN4QixNQUFNLEVBQUVHLEtBQUksRUFBRSxHQUFHLE1BQU1ELE9BQU9FLEtBQUssQ0FBQztRQUNsQ0EsT0FBT04sK0NBQUcsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7TUFjVCxDQUFDO0lBQ0g7SUFFRixPQUFPO1FBRUxPLE9BQU87WUFDTEMsV0FBV0g7UUFDYjtJQUNGO0FBQ0YsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL2Zyb250Ly4vc3JjL3BhZ2VzL2NoYXJhY3Rlci9baWRdLnRzeD9lMzM4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGdxbCAsdXNlUXVlcnl9IGZyb20gXCJAYXBvbGxvL2NsaWVudFwiO1xuaW1wb3J0IFJlYWN0LCB7RkMsIHVzZUVmZmVjdCwgdXNlU3RhdGV9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHtDaGFyYWN0ZXJBUEksIENoYXJhY3RlcnN9IGZyb20gXCJAL3R5cGVzXCI7XG5pbXBvcnQge3F1ZXJ5fSBmcm9tIFwiQC9zY2hlbWFzXCI7XG5pbXBvcnQgeyBHZXRTZXJ2ZXJTaWRlUHJvcHMgfSBmcm9tIFwibmV4dFwiO1xuaW1wb3J0IGdldENsaWVudCBmcm9tIFwiQC9saWJzL2NsaWVudFwiO1xuXG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRTdGF0aWNQYXRocygpOiBQcm9taXNlPHsgcHJvcHM6IHsgY2hhcmFjdGVyOiBDaGFyYWN0ZXJBUElbXSB9IH0+IHtcbiAgY29uc3QgY2xpZW50ID0gZ2V0Q2xpZW50KCk7XG4gIGNvbnN0IHsgZGF0YSB9ID0gYXdhaXQgY2xpZW50LnF1ZXJ5KHtcbiAgICBxdWVyeTogZ3FsYFxuICAgICAgICBxdWVyeSBjaGFyYWN0ZXIgKCRpZDogSUQhKSB7XG4gICAgICAgICAgY2hhcmFjdGVyIChpZDogJGlkKSB7XG4gICAgICAgICAgICBpbWFnZSxcbiAgICAgICAgICAgIG5hbWUsXG4gICAgICAgICAgICBnZW5kZXIsXG4gICAgICAgICAgICBsb2NhdGlvbiB7XG4gICAgICAgICAgICAgIG5hbWUsXG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlcGlzb2Rle1xuICAgICAgICAgICAgICBuYW1lLFxuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgYCxcbiAgICB9KTtcblxuICByZXR1cm4ge1xuXG4gICAgcHJvcHM6IHtcbiAgICAgIGNoYXJhY3RlcjogZGF0YSxcbiAgICB9LFxuICB9O1xufVxuXG5cbiJdLCJuYW1lcyI6WyJncWwiLCJSZWFjdCIsImdldENsaWVudCIsImdldFN0YXRpY1BhdGhzIiwiY2xpZW50IiwiZGF0YSIsInF1ZXJ5IiwicHJvcHMiLCJjaGFyYWN0ZXIiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./src/pages/character/[id].tsx\n");

/***/ }),

/***/ "@apollo/client":
/*!*********************************!*\
  !*** external "@apollo/client" ***!
  \*********************************/
/***/ ((module) => {

module.exports = require("@apollo/client");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./src/pages/character/[id].tsx"));
module.exports = __webpack_exports__;

})();