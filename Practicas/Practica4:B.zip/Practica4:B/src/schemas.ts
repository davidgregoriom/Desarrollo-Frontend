import {gql} from "@apollo/client";

export const query = gql`

    type Characters(page:$page){
        count:Int!
        pages:Int!
        prev:Int
        next:Int
        results:Charater!
    }

    type Character(id:$id){
        id:ID!
        name:String!
        status:String!
        species:String!
        type
        gender
        origin
        location
        image
        created
    }

    type Query {
        characters($page:Int!):[characters!]!
        character($id:Int!):character!
    }
  `
