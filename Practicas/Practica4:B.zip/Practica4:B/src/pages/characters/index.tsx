import Characters from "@/components/CharactersPage";
import { NextPage } from "next";




const Page=()=> {
  return (
    <>
      <Characters page={1}/>
    </>
  )
}

export default Page;
