import { gql ,useQuery} from "@apollo/client";
import React, {FC, useEffect, useState} from "react";
import {CharacterAPI, Characters} from "@/types";
import {query} from "@/schemas";
import { GetServerSideProps } from "next";
import getClient from "@/libs/client";


export async function getStaticPaths(): Promise<{ props: { character: CharacterAPI[] } }> {
  const client = getClient();
  const { data } = await client.query({
    query: gql`
        query character ($id: ID!) {
          character (id: $id) {
            image,
            name,
            gender,
            location {
              name,
            }
            episode{
              name,
            }
          }
        }
      `,
    });

  return {

    props: {
      character: data,
    },
  };
}


