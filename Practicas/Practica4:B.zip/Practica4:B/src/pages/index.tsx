import Head from 'next/head'
import Image from 'next/image'
import { Inter } from 'next/font/google'
import styles from '@/styles/Home.module.css'
import Link from 'next/link'

const inter = Inter({ subsets: ['latin'] })

export default function Home() {
  return (
    <>
      <>
      <Link href="/characters">Ir a la pag 1</Link>
      </>
      <>
      <Link href="/character/1">Ir a la pag del personaje</Link>
      </>
      <>
      <Link href="/location/1">Ir a la localización</Link>
      </>
      <>
      <Link href="/episode/1">Ir al episodio</Link>
      </>
    </>
  )
}
