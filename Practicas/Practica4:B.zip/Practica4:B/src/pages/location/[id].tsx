
import getSSRClient from "@/libs/client";
import { LocationAPI,CharacterAPI,Location} from "@/types";
import { gql } from "@apollo/client";
import { GetServerSideProps } from "next";
import  Locations  from "@/components/Location";

export const getServerSideProps:GetServerSideProps= async(context)=>{
    const client = getSSRClient();
    const id=context.params?.id;
    console.log(id);

    const { data } = await client.query({
        query: gql`
            query location ($id: ID!) {
              location (id: $id) {
                id,
                name,
                dimension,
                resident {
                  id
                  name,
                }
              }
            }
          `,variables:{id},
        });


    return{
        props:{
            data:data.data,
        }
    }
}
const LocationPage = ({data}:{data:Location})=>{
    return <Locations data={data}/>;

}
export default LocationPage;


