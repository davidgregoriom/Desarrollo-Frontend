import Episodes from "@/components/Episode";
import client from "@/libs/client";
import getSSRClient from "@/libs/client";
import { query } from "@/schemas";
import { EpisodeAPI ,Episode} from "@/types";
import { gql, useQuery } from "@apollo/client";
import { GetServerSideProps, NextPage } from "next";
import { useRouter } from "next/router";
import React, { FC } from "react";


export const getServerSideProps: GetServerSideProps = async (episode) => {

  const query= gql`
    query episode ($id: ID!) {
      episode (id: $id) {
        id,
        name,
        air_date,
        characters {
          id
          name,
        }
      }
    }
  `


  const route =useRouter();
  const {id} =route.query;
  console.log(id);

    const { data } = useQuery(query
      ,{variables:{id}});

  if(!episode){
    return<div>Cargando...</div>
  }
  return{
    props:{
      data:data.data,
    }
  }

}
const EpisodePage = ({data}:{data:Episode})=>{
  return <Episodes data={data}/>;

}
export default EpisodePage;
