export type CharactersAPI={
    count:number;
    pages:number;
    next?:number;
    prev?:number;
    results:Character[];
};

export type Characters = Omit<CharactersAPI,"results"> &{
    results:Characters[];
}

export type CharacterAPI={
    id:string;
    name:string;
    status:string;
    species:string;
    type:string;
    gender:string;
    origin:Location[];
    location:Location[];
    image:string;
    episode:Episode[];
    created:string;

}
export type Character= Omit<CharacterAPI,"origin"|"location">&{
    origin:Array<{
        id:string;
        name:string;
        type:string;
        dimension:string;
        residents:Character[]
        created:string;
    }>;
    location:Array<{
        id:string;
        name:string;
        type:string;
        dimension:string;
        residents:Character[]
        created:string;
    }>;
}

export type LocationAPI={
    id:string;
    name:string;
    type:string;
    dimension:string;
    residents:Character[]
    created:string;
}

export type Location= Omit<LocationAPI,"Character">&{
    Character:Array<{
        name:string;
    }>
}

export type EpisodeAPI={
    id:string;
    name:string;
    air_date:string;
    episode:string;
    characters:Character[];
    created:string;
}

export type Episode=Omit<EpisodeAPI,"Episode">&{
    Character:Array<{
        name:string;
    }>
}
