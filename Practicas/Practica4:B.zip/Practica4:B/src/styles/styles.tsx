import styled from "styled-components";
export const Contenedor = styled.div`
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 1rem;
`;

export const StyledC = styled.div`
  text-decoration: none;
  color: blue;
  display: flex;
  flex-direction: column;
  align-items: center;
`;

export const StyledI = styled.img`
  width: 100%;
  height: auto;
  object-fit: contain;
  max-width: 150px;
  max-height: 150px;
`;
