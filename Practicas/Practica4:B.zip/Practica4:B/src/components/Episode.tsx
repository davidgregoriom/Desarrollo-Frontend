import getClient from "@/libs/client";
import { Episode, EpisodeAPI, } from "@/types";
import { useQuery } from "@apollo/client";
import { FC, useEffect, useState } from "react";


const Episodes= ({ data }: { data: Episode})  =>{
  return (
    <>
        <h1>Episode</h1>
        <ul>
            <li key={data.id}>
              <h2>{data.name}</h2>
              <p>Emision: {data.air_date}</p>
              <p>Personajes: {data.characters.map(n=>{return(n.name)})}</p>
            </li>
        </ul>
    </>
  )
}
export default Episodes;
