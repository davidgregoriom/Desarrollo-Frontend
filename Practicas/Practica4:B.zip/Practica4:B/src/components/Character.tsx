import { Characters,Character } from "@/types";
import {query} from "@/schemas"



const character:unknown =({Character}: { Character: Character })=>{
    return (
      <div>
        <h1>Character</h1>
        <ul>
            <li key={Character.id}>
              <h2>{Character.name}</h2>
              <img src={Character.image} width="200px" height="200px"></img>
              <p>Genero: {Character.gender}</p>
              <p>Planeta: {Character.location.map(n=>{return(n.name)})}</p>
              <p>Episodios: {Character.episode.map(n=>{return(n.name)})}</p>
            </li>
        </ul>
      </div>
    );
  }

export default character;
