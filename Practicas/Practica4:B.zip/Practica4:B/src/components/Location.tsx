import {Location, LocationAPI}from "@/types";
import type { GetServerSideProps } from "next";
import { FC } from "react";

const Locations= ({ data }: { data: Location})  =>{
  return (
    <>
        <h1>Location</h1>
        <ul>
            <li key={data.id}>
              <h2>{data.name}</h2>
              <p>Dimension: {data.dimension}</p>
              <p>Planetas: {data.residents.map(n=>{return(n.name)})}</p>
            </li>
        </ul>
    </>
  )
}
export default Locations;
