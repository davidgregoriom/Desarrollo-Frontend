import {gql, useQuery} from "@apollo/client";
import getClient from "../libs/client";
import React, {FC, useEffect, useState} from "react";
import { query } from "@/schemas"
import { Characters, CharacterAPI } from "@/types";
import  {Contenedor,StyledC,StyledI} from "@/styles/styles"


const CharactersPage:FC<{page:number}>=({page})=> {

  const query = gql`
    query characters($page : Int!){
      characters(page:$page ){
      results{
        name,
        image,
        id
      }
    }
  }

  `

  const [charPage,setPage] = useState<number>(page);

  const {loading,error,data,refetch} = useQuery<Characters>(
    query,{
    variables: {
      page:charPage,
      prev:charPage-1,
      next:charPage+1
    }
  }
  );

  if(loading) return <div>Cargando...</div>
  if(error) return <div>Error</div>
  return(
    <div>
      <Contenedor>

        {data?.characters.results.map((character:CharacterAPI)=>{
          return (

              <StyledC>

                <StyledI src={character.image} width="200px" height="200px"></StyledI>

                <h1>{character.name }</h1>
              </StyledC>


          )
        })}

      </Contenedor>
          <button onClick={() => { setPage(charPage - 1); } }>Anterior</button>
          <button onClick={() => { setPage(charPage + 1); } }>Siguiente</button>
    </div>
  )
}

export default CharactersPage;
